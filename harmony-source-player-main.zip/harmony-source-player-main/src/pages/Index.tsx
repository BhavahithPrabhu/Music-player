import React from 'react';
import { MusicLibrary } from '@/components/MusicLibrary';
import { MusicPlayer } from '@/components/MusicPlayer';
import { PlayQueue } from '@/components/PlayQueue';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <MusicLibrary />
          </div>
          <div className="lg:col-span-1">
            <PlayQueue />
          </div>
        </div>
      </div>
      <MusicPlayer />
    </div>
  );
};

export default Index;
