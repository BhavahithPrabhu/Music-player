// Core interfaces for the music player system

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  artwork?: string;
  url: string;
  source: MusicSource;
}

export interface Playlist {
  id: string;
  name: string;
  songs: Song[];
}

export enum PlaybackState {
  STOPPED = 'stopped',
  PLAYING = 'playing',
  PAUSED = 'paused',
  LOADING = 'loading'
}

export enum MusicSource {
  LOCAL = 'local',
  SPOTIFY = 'spotify',
  AUDIODB = 'audiodb'
}

export interface PlaybackStatus {
  currentSong: Song | null;
  state: PlaybackState;
  currentTime: number;
  duration: number;
  volume: number;
  queue: Song[];
  currentIndex: number;
}

// Strategy Pattern Interface
export interface MusicSourceStrategy {
  initialize(): Promise<void>;
  getSongs(): Promise<Song[]>;
  playSong(song: Song): Promise<void>;
  pauseSong(): Promise<void>;
  resumeSong(): Promise<void>;
  stopSong(): Promise<void>;
  isSupported(): boolean;
  getSourceName(): string;
}

// Observer Pattern Interface
export interface PlaybackObserver {
  onStateChanged(status: PlaybackStatus): void;
  onProgressChanged(currentTime: number, duration: number): void;
  onSongChanged(song: Song | null): void;
  onQueueChanged(queue: Song[]): void;
}