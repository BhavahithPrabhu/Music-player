import { MusicSourceStrategy, Song, MusicSource } from '@/types/music';

export class AudioDBSource implements MusicSourceStrategy {
  private apiKey = '523532'; // Free test key from AudioDB
  private mockSongs: Song[] = [];

  async initialize(): Promise<void> {
    try {
      // Fetch trending artists and their tracks
      const response = await fetch(`https://www.theaudiodb.com/api/v1/json/${this.apiKey}/trending.php?country=us&type=itunes&format=albums`);
      const data = await response.json();
      
      // Convert to our Song format
      if (data.trending) {
        this.mockSongs = data.trending.slice(0, 5).map((album: any, index: number) => ({
          id: `audiodb-${index}`,
          title: album.strAlbum || 'Unknown Title',
          artist: album.strArtist || 'Unknown Artist',
          album: album.strAlbum || 'Unknown Album',
          duration: Math.floor(Math.random() * 240) + 120, // Random duration
          artwork: album.strAlbumThumb || '/api/placeholder/300/300',
          url: `audiodb:${album.idAlbum}`,
          source: MusicSource.AUDIODB
        }));
      }
    } catch (error) {
      console.warn('AudioDB API unavailable, using fallback data');
      // Fallback mock data
      this.mockSongs = [
        {
          id: 'audiodb-fallback-1',
          title: 'Streaming Hits',
          artist: 'Popular Artist',
          album: 'Chart Toppers',
          duration: 195,
          artwork: '/api/placeholder/300/300',
          url: 'audiodb:fallback-1',
          source: MusicSource.AUDIODB
        }
      ];
    }
  }

  async getSongs(): Promise<Song[]> {
    return this.mockSongs;
  }

  async playSong(song: Song): Promise<void> {
    console.log(`Playing AudioDB song: ${song.title}`);
    // Mock streaming from AudioDB
  }

  async pauseSong(): Promise<void> {
    console.log('Pausing AudioDB playback');
  }

  async resumeSong(): Promise<void> {
    console.log('Resuming AudioDB playback');
  }

  async stopSong(): Promise<void> {
    console.log('Stopping AudioDB playback');
  }

  isSupported(): boolean {
    return typeof fetch !== 'undefined';
  }

  getSourceName(): string {
    return 'AudioDB Streaming';
  }
}