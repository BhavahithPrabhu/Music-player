import { MusicSourceStrategy, Song, MusicSource } from '@/types/music';

export class LocalMusicSource implements MusicSourceStrategy {
  private mockSongs: Song[] = [];

  async initialize(): Promise<void> {
    // Mock local music library
    this.mockSongs = [
      {
        id: 'local-1',
        title: 'Midnight Jazz',
        artist: 'Sarah Chen',
        album: 'Evening Sessions',
        duration: 245,
        artwork: '/api/placeholder/300/300',
        url: '/music/midnight-jazz.mp3',
        source: MusicSource.LOCAL
      },
      {
        id: 'local-2',
        title: 'Urban Pulse',
        artist: 'Digital Dreams',
        album: 'City Lights',
        duration: 198,
        artwork: '/api/placeholder/300/300',
        url: '/music/urban-pulse.mp3',
        source: MusicSource.LOCAL
      },
      {
        id: 'local-3',
        title: 'Acoustic Sunset',
        artist: 'River Stone',
        album: 'Nature\'s Symphony',
        duration: 267,
        artwork: '/api/placeholder/300/300',
        url: '/music/acoustic-sunset.mp3',
        source: MusicSource.LOCAL
      }
    ];
  }

  async getSongs(): Promise<Song[]> {
    return this.mockSongs;
  }

  async playSong(song: Song): Promise<void> {
    console.log(`Playing local song: ${song.title}`);
    // In a real app, this would interface with the Web Audio API
  }

  async pauseSong(): Promise<void> {
    console.log('Pausing local playback');
  }

  async resumeSong(): Promise<void> {
    console.log('Resuming local playback');
  }

  async stopSong(): Promise<void> {
    console.log('Stopping local playback');
  }

  isSupported(): boolean {
    return typeof Audio !== 'undefined';
  }

  getSourceName(): string {
    return 'Local Files';
  }
}