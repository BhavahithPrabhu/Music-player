import { MusicSourceStrategy, Song, MusicSource } from '@/types/music';

export class SpotifyMockSource implements MusicSourceStrategy {
  private mockSongs: Song[] = [];
  private isInitialized = false;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    // Mock Spotify integration
    this.mockSongs = [
      {
        id: 'spotify-1',
        title: 'Electric Dreams',
        artist: 'Synthwave Valley',
        album: 'Neon Nights',
        duration: 223,
        artwork: '/api/placeholder/300/300',
        url: 'spotify:track:electric-dreams',
        source: MusicSource.SPOTIFY
      },
      {
        id: 'spotify-2',
        title: 'Cosmic Voyage',
        artist: 'Stellar Winds',
        album: 'Deep Space',
        duration: 312,
        artwork: '/api/placeholder/300/300',
        url: 'spotify:track:cosmic-voyage',
        source: MusicSource.SPOTIFY
      },
      {
        id: 'spotify-3',
        title: 'Ocean Waves',
        artist: 'Ambient Collective',
        album: 'Natural Sounds',
        duration: 189,
        artwork: '/api/placeholder/300/300',
        url: 'spotify:track:ocean-waves',
        source: MusicSource.SPOTIFY
      }
    ];
    
    this.isInitialized = true;
  }

  async getSongs(): Promise<Song[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    return this.mockSongs;
  }

  async playSong(song: Song): Promise<void> {
    console.log(`Playing Spotify song: ${song.title}`);
    // Mock Spotify Web Playback SDK integration
  }

  async pauseSong(): Promise<void> {
    console.log('Pausing Spotify playback');
  }

  async resumeSong(): Promise<void> {
    console.log('Resuming Spotify playback');
  }

  async stopSong(): Promise<void> {
    console.log('Stopping Spotify playback');
  }

  isSupported(): boolean {
    // Mock check for Spotify Web Playback SDK
    return true;
  }

  getSourceName(): string {
    return 'Spotify';
  }
}