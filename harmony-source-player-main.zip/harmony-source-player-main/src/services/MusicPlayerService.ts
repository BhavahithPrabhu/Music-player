// Singleton Pattern + Observer Pattern for the main music player
import { 
  PlaybackObserver, 
  PlaybackStatus, 
  PlaybackState, 
  Song, 
  MusicSource,
  MusicSourceStrategy 
} from '@/types/music';
import { MusicSourceFactory } from './MusicSourceFactory';

export class MusicPlayerService {
  private static instance: MusicPlayerService;
  private observers: PlaybackObserver[] = [];
  private currentSource: MusicSourceStrategy | null = null;
  private status: PlaybackStatus;
  private progressInterval: NodeJS.Timeout | null = null;

  private constructor() {
    this.status = {
      currentSong: null,
      state: PlaybackState.STOPPED,
      currentTime: 0,
      duration: 0,
      volume: 0.8,
      queue: [],
      currentIndex: -1
    };
  }

  // Singleton Pattern
  static getInstance(): MusicPlayerService {
    if (!MusicPlayerService.instance) {
      MusicPlayerService.instance = new MusicPlayerService();
    }
    return MusicPlayerService.instance;
  }

  // Observer Pattern - Subscribe to updates
  subscribe(observer: PlaybackObserver): void {
    this.observers.push(observer);
  }

  unsubscribe(observer: PlaybackObserver): void {
    this.observers = this.observers.filter(obs => obs !== observer);
  }

  private notifyObservers(): void {
    this.observers.forEach(observer => {
      observer.onStateChanged(this.status);
      observer.onSongChanged(this.status.currentSong);
      observer.onQueueChanged(this.status.queue);
      observer.onProgressChanged(this.status.currentTime, this.status.duration);
    });
  }

  // Load songs from all available sources
  async loadMusicLibrary(): Promise<Song[]> {
    const sources = await MusicSourceFactory.getAllSources();
    const allSongs: Song[] = [];

    for (const source of sources) {
      try {
        const songs = await source.getSongs();
        allSongs.push(...songs);
      } catch (error) {
        console.warn(`Failed to load songs from ${source.getSourceName()}:`, error);
      }
    }

    return allSongs;
  }

  // Queue Management
  addToQueue(song: Song): void {
    this.status.queue.push(song);
    this.notifyObservers();
  }

  removeFromQueue(index: number): void {
    if (index >= 0 && index < this.status.queue.length) {
      this.status.queue.splice(index, 1);
      if (this.status.currentIndex >= index && this.status.currentIndex > 0) {
        this.status.currentIndex--;
      }
      this.notifyObservers();
    }
  }

  setQueue(songs: Song[]): void {
    this.status.queue = [...songs];
    this.status.currentIndex = 0;
    this.notifyObservers();
  }

  // Playback Controls
  async play(song?: Song): Promise<void> {
    try {
      if (song) {
        // Play specific song
        this.status.currentSong = song;
        this.status.duration = song.duration;
        this.currentSource = await MusicSourceFactory.createSource(song.source);
      } else if (this.status.currentSong && this.status.state === PlaybackState.PAUSED) {
        // Resume current song
        if (this.currentSource) {
          await this.currentSource.resumeSong();
        }
      } else if (this.status.queue.length > 0) {
        // Play from queue
        const song = this.status.queue[this.status.currentIndex];
        this.status.currentSong = song;
        this.status.duration = song.duration;
        this.currentSource = await MusicSourceFactory.createSource(song.source);
      }

      if (this.currentSource && this.status.currentSong) {
        this.status.state = PlaybackState.LOADING;
        this.notifyObservers();

        await this.currentSource.playSong(this.status.currentSong);
        this.status.state = PlaybackState.PLAYING;
        this.startProgressTracking();
        this.notifyObservers();
      }
    } catch (error) {
      console.error('Playback failed:', error);
      this.status.state = PlaybackState.STOPPED;
      this.notifyObservers();
    }
  }

  async pause(): Promise<void> {
    if (this.currentSource && this.status.state === PlaybackState.PLAYING) {
      await this.currentSource.pauseSong();
      this.status.state = PlaybackState.PAUSED;
      this.stopProgressTracking();
      this.notifyObservers();
    }
  }

  async stop(): Promise<void> {
    if (this.currentSource) {
      await this.currentSource.stopSong();
    }
    this.status.state = PlaybackState.STOPPED;
    this.status.currentTime = 0;
    this.stopProgressTracking();
    this.notifyObservers();
  }

  async next(): Promise<void> {
    if (this.status.currentIndex < this.status.queue.length - 1) {
      this.status.currentIndex++;
      await this.play(this.status.queue[this.status.currentIndex]);
    }
  }

  async previous(): Promise<void> {
    if (this.status.currentIndex > 0) {
      this.status.currentIndex--;
      await this.play(this.status.queue[this.status.currentIndex]);
    }
  }

  setVolume(volume: number): void {
    this.status.volume = Math.max(0, Math.min(1, volume));
    this.notifyObservers();
  }

  seek(time: number): void {
    this.status.currentTime = Math.max(0, Math.min(this.status.duration, time));
    this.notifyObservers();
  }

  // Progress tracking
  private startProgressTracking(): void {
    this.stopProgressTracking();
    this.progressInterval = setInterval(() => {
      if (this.status.state === PlaybackState.PLAYING) {
        this.status.currentTime += 1;
        if (this.status.currentTime >= this.status.duration) {
          this.next(); // Auto-play next song
        } else {
          this.notifyObservers();
        }
      }
    }, 1000);
  }

  private stopProgressTracking(): void {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }

  // Getters
  getStatus(): PlaybackStatus {
    return { ...this.status };
  }

  getCurrentSong(): Song | null {
    return this.status.currentSong;
  }

  getQueue(): Song[] {
    return [...this.status.queue];
  }
}