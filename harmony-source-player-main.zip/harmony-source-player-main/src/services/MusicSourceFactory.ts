// Factory Pattern for creating music sources
import { MusicSourceStrategy, MusicSource } from '@/types/music';
import { LocalMusicSource } from './music-sources/LocalMusicSource';
import { SpotifyMockSource } from './music-sources/SpotifyMockSource';
import { AudioDBSource } from './music-sources/AudioDBSource';

export class MusicSourceFactory {
  private static sources: Map<MusicSource, MusicSourceStrategy> = new Map();

  static async createSource(sourceType: MusicSource): Promise<MusicSourceStrategy> {
    // Return existing instance if already created
    if (this.sources.has(sourceType)) {
      return this.sources.get(sourceType)!;
    }

    let source: MusicSourceStrategy;

    switch (sourceType) {
      case MusicSource.LOCAL:
        source = new LocalMusicSource();
        break;
      case MusicSource.SPOTIFY:
        source = new SpotifyMockSource();
        break;
      case MusicSource.AUDIODB:
        source = new AudioDBSource();
        break;
      default:
        throw new Error(`Unsupported music source: ${sourceType}`);
    }

    // Initialize the source
    await source.initialize();
    
    // Cache the initialized source
    this.sources.set(sourceType, source);
    
    return source;
  }

  static getAvailableSources(): MusicSource[] {
    return Object.values(MusicSource);
  }

  static async getAllSources(): Promise<MusicSourceStrategy[]> {
    const sources = await Promise.all(
      this.getAvailableSources().map(sourceType => this.createSource(sourceType))
    );
    return sources.filter(source => source.isSupported());
  }
}